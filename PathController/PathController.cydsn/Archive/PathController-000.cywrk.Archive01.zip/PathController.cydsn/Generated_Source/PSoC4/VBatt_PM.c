/*******************************************************************************
* File Name: VBatt.c  
* Version 2.20
*
* Description:
*  This file contains APIs to set up the Pins component for low power modes.
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "VBatt.h"

static VBatt_BACKUP_STRUCT  VBatt_backup = {0u, 0u, 0u};


/*******************************************************************************
* Function Name: VBatt_Sleep
****************************************************************************//**
*
* \brief Stores the pin configuration and prepares the pin for entering chip 
*  deep-sleep/hibernate modes. This function applies only to SIO and USBIO pins.
*  It should not be called for GPIO or GPIO_OVT pins.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None 
*  
* \sideeffect
*  For SIO pins, this function configures the pin input threshold to CMOS and
*  drive level to Vddio. This is needed for SIO pins when in device 
*  deep-sleep/hibernate modes.
*
* \funcusage
*  \snippet VBatt_SUT.c usage_VBatt_Sleep_Wakeup
*******************************************************************************/
void VBatt_Sleep(void)
{
    #if defined(VBatt__PC)
        VBatt_backup.pcState = VBatt_PC;
    #else
        #if (CY_PSOC4_4200L)
            /* Save the regulator state and put the PHY into suspend mode */
            VBatt_backup.usbState = VBatt_CR1_REG;
            VBatt_USB_POWER_REG |= VBatt_USBIO_ENTER_SLEEP;
            VBatt_CR1_REG &= VBatt_USBIO_CR1_OFF;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(VBatt__SIO)
        VBatt_backup.sioState = VBatt_SIO_REG;
        /* SIO requires unregulated output buffer and single ended input buffer */
        VBatt_SIO_REG &= (uint32)(~VBatt_SIO_LPM_MASK);
    #endif  
}


/*******************************************************************************
* Function Name: VBatt_Wakeup
****************************************************************************//**
*
* \brief Restores the pin configuration that was saved during Pin_Sleep(). This 
* function applies only to SIO and USBIO pins. It should not be called for
* GPIO or GPIO_OVT pins.
*
* For USBIO pins, the wakeup is only triggered for falling edge interrupts.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None
*  
* \funcusage
*  Refer to VBatt_Sleep() for an example usage.
*******************************************************************************/
void VBatt_Wakeup(void)
{
    #if defined(VBatt__PC)
        VBatt_PC = VBatt_backup.pcState;
    #else
        #if (CY_PSOC4_4200L)
            /* Restore the regulator state and come out of suspend mode */
            VBatt_USB_POWER_REG &= VBatt_USBIO_EXIT_SLEEP_PH1;
            VBatt_CR1_REG = VBatt_backup.usbState;
            VBatt_USB_POWER_REG &= VBatt_USBIO_EXIT_SLEEP_PH2;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(VBatt__SIO)
        VBatt_SIO_REG = VBatt_backup.sioState;
    #endif
}


/* [] END OF FILE */
